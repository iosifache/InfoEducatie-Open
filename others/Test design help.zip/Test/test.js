

$(document).ready(function() {
 

function clearOptions()
 {
    document.getElementById("oa11").checked=false;
    document.getElementById("oa12").checked=false;
    document.getElementById("oa21").checked=false;
    document.getElementById("oa22").checked=false;
    document.getElementById("oa31").checked=false;
    document.getElementById("oa32").checked=false;

    document.getElementById("ob11").checked=false;
    document.getElementById("ob12").checked=false;
    document.getElementById("ob21").checked=false;
    document.getElementById("ob22").checked=false;

    document.getElementById("oc11").checked=false;
    document.getElementById("oc12").checked=false;
    document.getElementById("oc21").checked=false;
    document.getElementById("oc22").checked=false;
    document.getElementById("oc31").checked=false;
    document.getElementById("oc32").checked=false;

 }


function EvaluateRaspuns()
{
  $.getJSON("raspunsuri.json", 
      function(data) {

		var scor=0;

      $.each(data, function(idx, obj){
		

             	//alert(data[idx].raspuns);
	     if(document.getElementById(data[idx].raspuns).checked)
		{
			$("#r"+idx).html("Corect");
			scor++;
		}
		else
		{
			$("#r"+idx).html("Gresit");
		}


                                  }
            );
 	
	alert("Raspunsuri corecte:"+scor);
    });
}

clearOptions();


$("#raspunsuri").on("click", function()
{
  EvaluateRaspuns();
});


});